
function ImageGrande(image)
{
    image.heigh=image.heigh*3 ;
    image.width=image.width*3;
}
function ImageOriginale(image)
{
    image.heigh=image.heigh/3;
    image.width=image.width/3;
}
